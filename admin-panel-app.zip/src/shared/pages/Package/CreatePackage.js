import React from "react";

import InputDiv from "../../components/Form/InputDiv";
import { Row, Button } from "react-bootstrap";
import "./CreatePackage.css";

export default function CreatePackage() {
  return (
    <div className="formdisplay">
      <div className="create__package__info">
        <div className="create__package__info__header">
          <p>Create Package</p>
        </div>
        <form>
          <div className="create__package__info__inputs">
            <div className="create__package__info__inputs__row">
              <InputDiv
                label="Package Name "
                className={"create__package__info__inputs__input"}
              />
              <InputDiv
                label="Short Description"
                className={"create__package__info__inputs__input"}
              />
              <InputDiv
                label=" Full Description"
                className={"create__package__info__inputs__input"}
              />
            </div>
            <div className="create__package__info__inputs__row">
              <InputDiv
                label="Package Type "
                className={"create__package__info__inputs__input"}
              />
              <InputDiv
                label="Composition"
                className={"create__package__info__inputs__input"}
              />
              <InputDiv
                label="Instruction"
                className={"create__package__info__inputs__input"}
              />
              <InputDiv
                label="Price"
                className={"create__package__info__inputs__input"}
              />
            </div>
            <Button
              style={{
                width: "fit-content",
                backgroundColor: "#57C262",
                border: "none",
                width: "150px",
                alignSelf: "flex-end",
                marginRight: "5%",
                marginTop: "5rem",
              }}
            >
              Create
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
